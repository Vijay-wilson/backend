const express = require("express");
const { getDatabasePool } = require("../db");

const router = express.Router();

router.post("/userAddon", async (req, res) => {
  try {
    const tempPool = getDatabasePool();

    const { orderId, status, uid, currentTime, totalPricePaid, paymentMethod, types, userdata, qty, subTotal, gst, deliveryCharge, deliveryTime } = req.body;

    try {
      const typesJSONB = JSON.stringify(types);
      const userdataJSONB = JSON.stringify(userdata); 

      const result = await tempPool.query(
        `
        INSERT INTO addon (orderId, status, uid, currentTime, totalPricePaid, paymentMethod, types, userdata, qty, subTotal, gst, deliveryCharge, deliveryTime)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
        RETURNING *;
        `,
        [orderId, status, uid, currentTime, totalPricePaid, paymentMethod, typesJSONB, userdataJSONB, qty, subTotal, gst, deliveryCharge, deliveryTime]
      );

      const addon = result.rows[0];

      res.json({ status: true, message: "Addon added successfully", addon });
    } catch (error) {
      if (error.code === '23505' && error.constraint === 'addon_pkey') {
        return res.status(400).json({ status: false, message: "Order ID already exists" });
      }
      
      console.log("Error adding addon:", error);
      res.status(500).json({ status: false, message: "Internal Server Error" });
    }
  } catch (error) {
    console.log("Error creating pool:", error);
    res.status(500).json({ status: false, message: "Internal Server Error" });
  }
});


router.get("/userAddon", async (req, res) => {
  try {
    const tempPool = getDatabasePool();

    const getAddonQuery = 'SELECT * FROM addon';

    const result = await tempPool.query(getAddonQuery);

    res.json(result.rows);
  } catch (error) {
    console.error('Error retrieving addon data:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

router.put('/userAddon/:orderId', async (req, res) => {
  const { orderId } = req.params;
  const { status } = req.body;

  const tempPool = getDatabasePool();

  const updateStatusQuery = `
    UPDATE addon
    SET status = $1
    WHERE orderId = $2
  `;

  try {
    await tempPool.query(updateStatusQuery, [status, orderId]);
    res.status(200).json({ message: 'Status updated successfully', status });

  } catch (error) {
    console.error('Error updating status:', error);
    res.status(500).json({ error: 'Internal server error' });
  } finally {
    await tempPool.end();
  }
});


router.post('/getAddonData', async (req, res) => {
  const { uid } = req.body;
  const tempPool = getDatabasePool();

  try {
    const query = {
      text: 'SELECT * FROM addon WHERE uid = $1',
      values: [uid],
    };

    const result = await tempPool.query(query);

    // Send the fetched data as response
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching addon data:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.get('/routes', async (req, res) => {
  const tempPool = getDatabasePool();

  const fetchRoutesQuery = `
    SELECT route_name, value FROM routes;
  `;

  try {
    const result = await tempPool.query(fetchRoutesQuery);
    const routes = result.rows;
    res.status(200).json(routes);
  } catch (error) {
    console.error("Error fetching routes:", error);
    res.status(500).json({ error: 'Internal Server Error' });
  } finally {
    await tempPool.end();
  }
});

router.get('/meal-prices', async (req, res) => {
  const tempPool = getDatabasePool();
  try {
    const query = `
      SELECT meal_type, price, is_vegetarian 
      FROM meal_prices 
      WHERE is_active = true 
      ORDER BY meal_type, is_vegetarian`;
    
    const result = await tempPool.query(query);
    
    // Transform the result into a more user-friendly format
    const mealPrices = {
      Breakfast: null,
      Lunch: { Veg: null, NonVeg: null },
      Dinner: null,
      Special: null
    };

    result.rows.forEach(row => {
      if (row.meal_type === 'Lunch') {
        mealPrices.Lunch[row.is_vegetarian ? 'Veg' : 'NonVeg'] = row.price;
      } else if (row.meal_type === 'Special') {
        mealPrices.Special = row.price;
      } else {
        mealPrices[row.meal_type] = row.price;
      }
    });

    res.json(mealPrices);
  } catch (error) {
    console.error('Error fetching meal prices:', error);
    res.status(500).json({ error: 'Internal server error' });
  } finally {
    await tempPool.end();
  }
});

module.exports = router;
