const express = require("express");
const { getDatabasePool } = require("../db");

const router = express.Router();

router.post('/updatepush', async (req, res) => {
  const { alert_id, title, message, version, timestamp, update_url, dismissable } = req.body;

  if (!alert_id || !title || !message || !version || !timestamp || !update_url || !dismissable) {
    return res.status(400).json({ message: "Missing required fields" });
  }

  const tempPool = getDatabasePool();

  const updateQuery = `
    INSERT INTO updatepush (alert_id, title, message, version, timestamp, update_url, dismissable)
    VALUES ($1, $2, $3, $4, $5, $6, $7)
    ON CONFLICT (alert_id) DO UPDATE
    SET title = $2, message = $3, version = $4, timestamp = $5, update_url = $6, dismissable = $7;
  `;

  try {
    await tempPool.query(updateQuery, [alert_id, title, message, version, timestamp, update_url, dismissable]);
    res.status(200).json({ message: "Update successful" });
  } catch (error) {
    console.error("Error updating table:", error);
    res.status(500).json({ message: "Internal server error" });
  } finally {
    await tempPool.end();
  }
});

router.get('/updatepush', async (req, res) => {
  const tempPool = getDatabasePool();

  const fetchDataQuery = 'SELECT * FROM updatepush;';

  try {
    const { rows } = await tempPool.query(fetchDataQuery);
    res.status(200).json(rows);
  } catch (error) {
    console.log("Error fetching data:", error);
    res.status(500).send("Error fetching data");
  } finally {
    await tempPool.end();
  }
});
router.delete('/updatepush', async (req, res) => {
  const { version } = req.body;

  if (!version) {
    return res.status(400).json({ message: "Missing required field: version" });
  }

  const tempPool = getDatabasePool();

  const deleteQuery = `
    DELETE FROM updatepush WHERE version = $1;
  `;

  try {
    await tempPool.query(deleteQuery, [version]);
    res.status(200).json({ message: `Records with version ${version} deleted successfully` });
  } catch (error) {
    console.error("Error deleting records:", error);
    res.status(500).json({ message: "Internal server error" });
  } finally {
    await tempPool.end();
  }
});
module.exports = router;
