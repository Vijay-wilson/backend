const config = require("../config");

const validateAPIKey = (req, res, next) => {
  const apiKey = req.headers['x-api-key'];
  if (!apiKey || apiKey !== config.apiKey) {
    return res.status(401).json({ status: false, error: "Unauthorized: Invalid API key" });
  }
  next();
};

module.exports = validateAPIKey;
