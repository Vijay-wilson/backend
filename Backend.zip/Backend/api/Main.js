const express = require("express");
const { getDatabasePool } = require("../db");
const jwt = require("jsonwebtoken");
const config = require("../config");
const crypto = require('crypto');

const router = express.Router();

const validateAPIKey = require("./apikeyMiddleware");
// Function to generate random alphabetic characters
function generateRandomString(length) {
    let result = '';
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
    const charactersLength = characters.length;
    for (let i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
  }
  
  const jwtSecretKey = crypto.randomBytes(32).toString('hex');
  
  router.post("/register", validateAPIKey, async (req, res) => {
    try {
      const tempPool = getDatabasePool();
  
      const {
        FirstName, LastName, PhoneNumber, CreatedAt, HouseName,
        RoadAndLocation, Area, Locality, Route, user_info,
        FirebaseToken, loginstatus 
      } = req.body;
  
      try {
        // Get the maximum id from the users table
        const maxIdResult = await tempPool.query("SELECT MAX(id) FROM users");
        const maxId = maxIdResult.rows[0].max || 0; 
  
        // Generate UID 
        const uid = PhoneNumber + generateRandomString(4);
  
        // Use the next available id
        const result = await tempPool.query(
          `INSERT INTO users (id, first_name, last_name, phone_number, created_at, house_name, 
            road_and_location, area, locality, route, jwt_token, user_info, uid, FirebaseToken, loginstatus) 
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15) RETURNING *`,
          [
            maxId + 1, FirstName, LastName, PhoneNumber, CreatedAt, HouseName,
            RoadAndLocation, Area, Locality, Route, jwt.sign({ PhoneNumber }, jwtSecretKey),
            user_info, uid, FirebaseToken, loginstatus 
          ]
        );
  
        const user = result.rows[0];
        const token = user.jwt_token;
  
        const responseObject = {
          status: true,
          message: "User registered successfully",
          id: user.id,
          first_name: user.first_name,
          last_name: user.last_name,
          phone_number: user.phone_number,
          created_at: user.created_at,
          house_name: user.house_name,
          road_and_location: user.road_and_location,
          area: user.area,
          locality: user.locality,
          route: user.route,
          jwt_token: token,
          user_info: user.user_info,
          uid: user.uid,
          firebasetoken: user.FirebaseToken,
          loginstatus: user.loginstatus 
        };
  
        res.json(responseObject);
      } catch (error) {
        // Check if the error is due to a duplicate key violation
        if (error.code === '23505' && error.constraint === 'users_phone_number_key') {
          return res.json({ status: false, message: "Phone number already exists" });
        }
  
        console.error("Error registering user:", error);
        res.status(500).json({ status: false, error: "Internal Server Error" });
      }
    } catch (error) {
      console.error("Error creating pool:", error);
      res.status(500).json({ status: false, error: "Internal Server Error" });
    }
  });
  
  
  
  router.post("/signin", validateAPIKey, async (req, res) => {
    try {
      const tempPool = getDatabasePool();
      const { PhoneNumber } = req.body;
  
      try {
        const result = await tempPool.query("SELECT * FROM users WHERE phone_number = $1", [PhoneNumber]);
  
        if (result.rows.length === 0) {
          return res.json([{ status: false, message: "User not available" }]);
        }
  
        const user = result.rows[0];
        await tempPool.query("UPDATE users SET loginstatus = $1 WHERE phone_number = $2", [true, PhoneNumber]);
  
        res.json({
          id: user.id,
          status: true,
          message: "Successfully logged in",
          first_name: user.first_name,
          last_name: user.last_name,
          phone_number: user.phone_number,
          created_at: user.created_at,
          house_name: user.house_name,
          road_and_location: user.road_and_location,
          area: user.area,
          locality: user.locality,
          route: user.route,
          jwt_token: user.jwt_token,
          user_info: user.user_info, 
          uid: user.uid,
          firebase_token: user.FirebaseToken,
          loginstatus: true 
        });
      } catch (error) {
        console.error("Error signing in user:", error);
        res.status(500).json([{ status: false, error: "Internal Server Error" }]);
      }
    } catch (error) {
      console.error("Error creating pool:", error);
      res.status(500).json([{ status: false, error: "Internal Server Error" }]);
    }
  });
  
  
  
  // router.post("/signout",validateAPIKey, async (req, res) => {
  //   try {
  //     const tempPool = getDatabasePool();
  
  //     const { PhoneNumber } = req.body;
  
  //     // Check x-api-key header
  //     const apiKeyHeader = req.headers['x-api-key'];
  //     if (apiKeyHeader !== config.apiKey) {
  //       return res.status(401).json({ status: false, error: "Unauthorized: Invalid API key" });
  //     }
  
  //     // Check Authorization header
  //     const authorizationHeader = req.headers['authorization'];
  //     if (!authorizationHeader || !authorizationHeader.startsWith('Bearer ')) {
  //       return res.status(401).json({ status: false, error: "Unauthorized: Missing or invalid Authorization header" });
  //     }
  
  //     const tokenFromHeader = authorizationHeader.split(' ')[1];
  
  //     try {
  //       const result = await tempPool.query("SELECT * FROM users WHERE phone_number = $1", [PhoneNumber]);
  
  //       if (result.rows.length === 0) {
  //         return res.json({ status: false, message: "User not found" });
  //       }
  
  //       const user = result.rows[0];
  
  //       if (tokenFromHeader !== user.jwt_token) {
  //         return res.status(401).json({ status: false, error: "Unauthorized: Invalid token" });
  //       }
  
  //       const newToken = jwt.sign({ PhoneNumber }, jwtSecretKey);
  //       await tempPool.query("UPDATE users SET jwt_token = $1 WHERE phone_number = $2", [newToken, PhoneNumber]);
  //       res.json({
  //         status: true,
  //         message: "Logout success",
  //         new_token: newToken,  
  //       });
  //     } catch (error) {
  //       console.error("Error during signout:", error);
  //       res.status(500).json({ status: false, error: "Internal Server Error" });
  //     }
  //   } catch (error) {
  //     console.error("Error creating pool:", error);
  //     res.status(500).json({ status: false, error: "Internal Server Error" });
  //   }
  // });
  
  router.post("/signout", validateAPIKey, async (req, res) => {
    try {
      const tempPool = getDatabasePool();
      const { PhoneNumber } = req.body;
  
      try {
        const result = await tempPool.query("SELECT * FROM users WHERE phone_number = $1", [PhoneNumber]);
  
        if (result.rows.length === 0) {
          return res.json({ status: false, message: "User not available" });
        }

        await tempPool.query("UPDATE users SET loginstatus = $1 WHERE phone_number = $2", [false, PhoneNumber]);
  
        res.json({ status: true, message: "Successfully logged out" });
      } catch (error) {
        console.error("Error signing out user:", error);
        res.status(500).json({ status: false, error: "Internal Server Error" });
      }
    } catch (error) {
      console.error("Error creating pool:", error);
      res.status(500).json({ status: false, error: "Internal Server Error" });
    }
  });
  
  // Get all user dashboard
  
  router.get("/users", async (req, res) => {
    let tempPool;
  
    try {
      tempPool = getDatabasePool();
  
      const getUsersQuery = 'SELECT * FROM users';
  
      const result = await tempPool.query(getUsersQuery);
  
      res.json(result.rows);
    } catch (error) {
      console.error('Error retrieving users:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    } finally {
      if (tempPool) {
        await tempPool.end();
      }
    }
  });
  router.put('/users/:phoneNumber', async (req, res) => {
    const phoneNumber = req.params.phoneNumber;
    const { firstName, lastName, houseName, roadAndLocation, area, locality, route } = req.body;
    tempPool = getDatabasePool();
    try {
      const updateUserQuery = `
        UPDATE users 
        SET 
          first_name = $1,
          last_name = $2,
          house_name = $3,
          road_and_location = $4,
          area = $5,
          locality = $6,
          route = $7
        WHERE phone_number = $8
      `;
      
      const values = [firstName, lastName, houseName, roadAndLocation, area, locality, route, phoneNumber];
      
      const result = await tempPool.query(updateUserQuery, values);
      
      res.status(200).json({ message: 'User information updated successfully' });
    } catch (error) {
      console.error('Error updating user information:', error);
      res.status(500).json({ error: 'An error occurred while updating user information' });
    }
  });
  
// Delete user
router.post('/deleteuser', async (req, res) => {
    const { PhoneNumber, FullName, Reason } = req.body;
  
    // Insert data into deleteuser table
    try {
      const tempPool = getDatabasePool();
      const insertQuery = 'INSERT INTO deleteuser (PhoneNumber, FullName, Reason) VALUES ($1, $2, $3)';
      await tempPool.query(insertQuery, [PhoneNumber, FullName, Reason]);
      res.status(200).json({ message: 'Request submit successfully' });
    } catch (error) {
      if (error.code === '23505') { 
        res.status(400).json({ message: 'Phone number already requested' });
      } else {
        console.log('Error adding data:', error);
        res.status(500).json({ error: 'Internal server error' });
      }
    }
  });

module.exports = router;