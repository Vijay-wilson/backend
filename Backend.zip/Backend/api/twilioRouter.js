const express = require('express');
const router = express.Router();
const twilio = require('twilio');
const bodyParser = require('body-parser');
const validateAPIKey = require("../api/apikeyMiddleware");


// Twilio credentials Lalas orginal
// const accountSid = "ACb3077f569065a1509ae5dc32376378d3";
// const authToken = "a5f0c7f72ad25f0377e6a0fb148dff15";
// const verifySid = "VA63e65af0af250cf4a40139f3acf4a697";


// Twilio credentials Test
const accountSid = "AC7d2346a846d711122a7bcbd95ce407a1";
const authToken = "3c210c09f06f4422b66057d953386c14";
const verifySid = "VA4c39d32a9d98f134cc1f50e973c45f83";
const twilioClient = new twilio(accountSid, authToken);

router.use(bodyParser.urlencoded({ extended: false }));
router.use(bodyParser.json());

// In-memory cache for rate limiting
const otpRequestCache = new Map();

// Generate OTP
function generateOTP() {
  return Math.floor(1000 + Math.random() * 9000).toString();
}

// Rate limiting middleware
function rateLimitOTP(req, res, next) {
  const { to } = req.body;
  const now = Date.now();
  const lastRequestTime = otpRequestCache.get(to) || 0;
  
  // 5 minutes in milliseconds
  if (now - lastRequestTime < 5 * 60 * 1000) { 
    return res.status(429).json({ error: 'Rate limit exceeded. Please try again later.' });
  }
  
  otpRequestCache.set(to, now);
  next();
}

// Send OTP via SMS
router.post('/send-otp', validateAPIKey, rateLimitOTP, async (req, res) => {
  const { to } = req.body;
  if (!to) {
    return res.status(400).json({ error: 'Missing phone number' });
  }
  
  const otp = generateOTP();
  
  try {
    await twilioClient.verify.services(verifySid)
      .verifications
      .create({
        to: `+${to}`,
        channel: 'sms',
        code: otp
      });
    return res.status(200).json({ success: true, message: 'OTP sent successfully' });
  } catch (error) {
    console.error(error);
    if (error.code === 60410) {
      return res.status(403).json({ message: 'The destination phone number has been temporarily blocked by Twilio due to fraudulent activities. Please contact support or use a different phone number.' });
    }
    return res.status(500).json({ message: 'Failed to send OTP' });
  }
});

// Verify OTP
router.post('/verify-otp', validateAPIKey, async (req, res) => {
  const { to, otp } = req.body;

  if (!to || !otp) {
    return res.status(400).json({ message: 'Missing phone number or OTP' });
  }

  try {
    const verificationCheck = await twilioClient.verify.services(verifySid)
      .verificationChecks
      .create({
        to: `+${to}`,
        code: otp
      });

    if (verificationCheck.status === 'approved') {
      return res.status(200).json({ success: true, message: 'OTP verified successfully' });
    } else {
      return res.status(400).json({ message: 'Invalid OTP' });
    }
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: 'Failed to verify OTP' });
  }
});

module.exports = router;