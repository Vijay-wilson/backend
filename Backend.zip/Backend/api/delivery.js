const express = require("express");
const { getDatabasePool } = require("../db");

const router = express.Router();


router.post('/delivery', async (req, res) => {
  const { uid, route, deliveryuser, userdata, deliverydata, status, order_id } = req.body;

  // Check if order_id exists
  if (!order_id) {
      return res.status(400).json({ success: false, error: 'Order ID is required.' });
  }

  const tempPool = getDatabasePool();
  const insertQuery = `
      INSERT INTO delivery (uid, route, deliveryuser, userdata, deliverydata, status, order_id)
      VALUES ($1, $2, $3, $4, $5, $6, $7)
      RETURNING *;
  `;

  try {
      const userDataJSON = JSON.stringify(userdata);
      const deliveryDataJSON = JSON.stringify(deliverydata);

      const result = await tempPool.query(insertQuery, [uid, route, deliveryuser, userDataJSON, deliveryDataJSON, status, order_id]);
      res.status(201).json({ success: true, data: result.rows[0] });
  } catch (error) {
      if (error.code === '23505') { // PostgreSQL unique violation error code
          res.status(409).json({ success: false, error: 'Please use a unique id or order id.' });
      } else {
          console.error('Error inserting data into delivery table:', error);
          res.status(500).json({ success: false, error: 'An error occurred while inserting data' });
      }
  }
});

  
  router.get('/delivery', async (req, res) => {
    const tempPool = getDatabasePool();
    try {
      const result = await tempPool.query('SELECT * FROM delivery');
      res.json(result.rows);
    } catch (error) {
      res.status(500).json({ error: 'Error getting deliveries', message: error.message });
    }
  });
  
  const updateDeliveryStatus = async (uid, newStatus) => {
    const pool = getDatabasePool();
    const updateDeliveryStatusQuery = `
      UPDATE delivery
      SET status = $1
      WHERE uid = $2
    `;
    try {
      await pool.query(updateDeliveryStatusQuery, [newStatus, uid]);
      console.log(`Delivery with UID ${uid} status updated successfully.`);
      return true; 
    } catch (error) {
      console.error(`Error updating delivery status: ${error}`);
      return false; 
    } finally {
      await pool.end();
    }
  };
  
  router.put('/delivery', async (req, res) => {
    const { uid, newStatus } = req.body;
  
    if (!uid || newStatus === undefined) {
      return res.status(400).json({ error: 'Both uid and newStatus are required.' });
    }
  
    const success = await updateDeliveryStatus(uid, newStatus);
    if (success) {
      return res.status(200).json({ message: 'Delivery completed successfully.' });
    } else {
      return res.status(500).json({ error: 'Failed to update delivery status.' });
    }
  });


module.exports = router;