const express = require("express");
const { getDatabasePool } = require("../db");

const router = express.Router();


router.post('/delivery', async (req, res) => {
  const { deliveryuser, deliverydata, status, delivery_type, order_id } = req.body; 

  if (!order_id) {
    return res.status(400).json({ success: false, error: 'Order ID is required.' });
  }

  const tempPool = getDatabasePool();
  const insertQuery = `
    INSERT INTO delivery (deliveryuser, deliverydata, status, delivery_type, order_id)
    VALUES ($1, $2, $3, $4, $5)
    RETURNING *;
  `;

  try {
    const deliveryDataJSON = JSON.stringify(deliverydata);

    const result = await tempPool.query(insertQuery, [deliveryuser, deliveryDataJSON, status, delivery_type, order_id]);
    res.status(201).json({ success: true, data: result.rows[0] });
  } catch (error) {
    if (error.code === '23505') { // PostgreSQL unique violation error code
      res.status(409).json({ success: false, error: 'Please use a unique id or order id.' });
    } else {
      console.error('Error inserting data into delivery table:', error);
      res.status(500).json({ success: false, error: 'An error occurred while inserting data' });
    }
  }
});


  
  router.get('/delivery', async (req, res) => {
    const tempPool = getDatabasePool();
    try {
      const result = await tempPool.query('SELECT * FROM delivery');
      res.json(result.rows);
    } catch (error) {
      res.status(500).json({ error: 'Error getting deliveries', message: error.message });
    }
  });
  
  router.put('/delivery', async (req, res) => {
    const { order_id, newStatus } = req.body;
  
    if (!order_id || newStatus === undefined) {
      return res.status(400).json({ error: 'Both order_id and newStatus are required.' });
    }
  
    const success = await updateDeliveryStatus(order_id, newStatus);
    if (success) {
      return res.status(200).json({ message: 'Delivery status updated successfully.' });
    } else {
      return res.status(500).json({ error: 'Failed to update delivery status.' });
    }
});

const updateDeliveryStatus = async (order_id, newStatus) => {
    const tempPool = getDatabasePool();
    const updateDeliveryStatusQuery = `
      UPDATE delivery
      SET status = $1
      WHERE order_id = $2
    `;
    try {
      await tempPool.query(updateDeliveryStatusQuery, [newStatus, order_id]);
      console.log(`Delivery with order_id ${order_id} status updated successfully.`);
      return true; 
    } catch (error) {
      console.error(`Error updating delivery status: ${error}`);
      return false; 
    } finally {
      await tempPool.end();
    }
};

  const formatDate = () => {
    const now = new Date();
    
    const pad = (n) => (n < 10 ? '0' + n : n);
  
    const day = pad(now.getDate());
    const month = pad(now.getMonth() + 1);
    const year = now.getFullYear();
    
    let hours = now.getHours();
    const minutes = pad(now.getMinutes());
    const seconds = pad(now.getSeconds());
    
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12; 
    hours = pad(hours);
  
    return `${day}/${month}/${year} ${hours}:${minutes}:${seconds} ${ampm}`;
  };
  
  router.post('/deliverycomplete', async (req, res) => {
    const { order_id, uid, comment, rating, delivery_user, delivery_status, delivery_type, rating_status } = req.body;
    const tempPool = getDatabasePool();
    
    // Get the current date and time in the desired format
    const delivery_date = formatDate();
  
    const insertQuery = `
      INSERT INTO deliverycomplete (order_id, uid, comment, rating, delivery_user, delivery_status, delivery_type, delivery_date, rating_status)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
      RETURNING *;
    `;
  
    try {
      const result = await tempPool.query(insertQuery, [order_id, uid, comment, rating, delivery_user, delivery_status, delivery_type, delivery_date, rating_status]);
      res.status(201).json(result.rows[0]);
    } catch (error) {
      console.error('Error inserting data:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    } finally {
      await tempPool.end();
    }
  });
  
  
  router.get('/deliverycomplete', async (req, res) => {
    const getDeliveriesQuery = 'SELECT * FROM deliverycomplete';
    const tempPool = getDatabasePool();
    try {
      const result = await tempPool.query(getDeliveriesQuery);
      res.json(result.rows);
    } catch (error) {
      console.error('Error fetching delivery data:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  });
  
  router.get('/deliverycomplete/:uid', async (req, res) => {
    const { uid } = req.params;
    const getDeliveryByUidQuery = 'SELECT * FROM deliverycomplete WHERE uid = $1';
    const tempPool = getDatabasePool();
    try {
      const result = await tempPool.query(getDeliveryByUidQuery, [uid]);
      if (result.rows.length > 0) {
        res.json(result.rows);
      } else {
        res.status(404).json({ error: 'No delivery found for the given uid' });
      }
    } catch (error) {
      console.error('Error fetching delivery data by uid:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  });

router.put('/update-rating/:id', async (req, res) => {
  const { id } = req.params;
  const { rating, comment, rating_status } = req.body;
  const tempPool = getDatabasePool();
  const updateQuery = `
    UPDATE deliverycomplete
    SET
      rating = $1,
      comment = $2,
      rating_status = $3
    WHERE id = $4;
  `;

  try {
    const result = await tempPool.query(updateQuery, [
      rating,
      comment,
      rating_status,
      id,
    ]);

    if (result.rowCount === 0) {
      res.status(404).send('Delivery entry not found');
    } else {
      res.status(200).send('Delivery entry updated successfully');
    }
  } catch (error) {
    console.error('Error updating delivery entry:', error);
    res.status(500).send('Internal Server Error');
  }
});

router.post('/updateRatingStatus', async (req, res) => {
  const { uid } = req.body;
  const tempPool = getDatabasePool();

  if (!uid) {
    return res.status(400).json({ error: 'uid is required' });
  }

  const checkUidQuery = `
    SELECT 1
    FROM deliverycomplete
    WHERE uid = $1
  `;

  const updateRatingStatusQuery = `
    UPDATE deliverycomplete
    SET rating_status = false
    WHERE uid = $1
  `;

  try {
    const checkResult = await tempPool.query(checkUidQuery, [uid]);

    if (checkResult.rowCount === 0) {
      return res.status(404).json({ error: 'uid not found' });
    }

    await tempPool.query(updateRatingStatusQuery, [uid]);
    res.status(200).json({ message: 'rating_status updated successfully' });
  } catch (error) {
    console.error('Error updating rating_status:', error);
    res.status(500).json({ error: 'An error occurred while updating rating_status' });
  } finally {
    await tempPool.end();
  }
});



module.exports = router;