const express = require("express");
const { getDatabasePool } = require("../db");
const router = express.Router();


// addons dashboard admin_addon
router.post("/addFoodItem", async (req, res) => {
  let tempPool;

  try {
    tempPool = getDatabasePool();

    // Extract data from the request body
    const {
      item_name,
      item_image,
      item_url,
      item_type,
      item_description,
      item_price,
      status,
      item_qty
    } = req.body;

    // Insert the new food item into the database
    const result = await tempPool.query(
      `
      INSERT INTO admin_addon (item_name, item_image, item_url, item_type, item_description, item_price, status, item_qty)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      RETURNING *;
      `,
      [item_name, item_image, item_url, item_type, item_description, item_price, status, item_qty]
    );

    const foodItem = result.rows[0];

    // Send the response with the new food item
    res.json({ status: true, message: "Food item added successfully", foodItem });
  } catch (error) {
    console.log("Error adding food item:", error);
    res.status(500).json({ status: false, error: "Internal Server Error" });
  } finally {
    if (tempPool) {
      await tempPool.end();
    }
  }
});


  
  // addons dashboard delete
  router.delete('/deleteFoodItem/:id', async (req, res) => {
    const { id } = req.params;
    let tempPool;
  
    try {
      tempPool = getDatabasePool();
      const query = 'DELETE FROM admin_addon WHERE id = $1';
      const result = await tempPool.query(query, [id]);
  
      if (result.rowCount === 1) {
        res.status(200).json({ message: 'Item deleted successfully' });
      } else {
        res.status(404).json({ message: 'Item not found' });
      }
    } catch (error) {
      console.error('Error deleting food item:', error);
      res.status(500).json({ message: 'Internal server error' });
    } finally {
      if (tempPool) {
        await tempPool.end();
      }
    }
  });

  router.get("/getFoodItems", async (req, res) => {
    let tempPool;
  
    try {
      tempPool = getDatabasePool();
      const getFoodItemsQuery = 'SELECT * FROM admin_addon';
      const result = await tempPool.query(getFoodItemsQuery);
  
      res.json(result.rows);
    } catch (error) {
      console.error('Error retrieving food items:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    } finally {
      if (tempPool) {
        await tempPool.end();
      }
    }
  });
  router.put("/increment/:id", async (req, res) => {
    const { id } = req.params;
    let tempPool;
  
    try {
      tempPool = getDatabasePool();
      const result = await tempPool.query(
        'UPDATE admin_addon SET item_qty = item_qty + 1 WHERE id = $1 RETURNING item_qty',
        [id]
      );
  
      if (result.rowCount === 1) {
        const updatedQty = result.rows[0].item_qty;
        res.status(200).json({ message: 'Quantity incremented successfully', qty: updatedQty });
      } else {
        res.status(404).json({ message: 'Item not found' });
      }
    } catch (error) {
      console.error('Error incrementing quantity:', error);
      res.status(500).json({ message: 'Internal server error' });
    } finally {
      if (tempPool) {
        await tempPool.end();
      }
    }
  });
  router.put("/decrement/:id", async (req, res) => {
    const { id } = req.params;
    let tempPool;
  
    try {
      tempPool = getDatabasePool();
      const result = await tempPool.query(
        'UPDATE admin_addon SET item_qty = item_qty - 1 WHERE id = $1 AND item_qty > 0 RETURNING item_qty',
        [id]
      );
  
      if (result.rowCount === 1) {
        const updatedQty = result.rows[0].item_qty;
        res.status(200).json({ message: 'Quantity decremented successfully', qty: updatedQty });
      } else {
        res.status(404).json({ message: 'Item not found or quantity already zero' });
      }
    } catch (error) {
      console.error('Error decrementing quantity:', error);
      res.status(500).json({ message: 'Internal server error' });
    } finally {
      if (tempPool) {
        await tempPool.end();
      }
    }
  });
  
  router.put("/update-item/:id", async (req, res) => {
    const { id } = req.params;
    const { item_name, item_price } = req.body;
  
    if (!item_name || !item_price) {
      return res.status(400).json({ error: "item_name and item_price are required" });
    }
    tempPool = getDatabasePool();
    try {
      const updateQuery = `
        UPDATE admin_addon
        SET item_name = $1, item_price = $2
        WHERE id = $3
        RETURNING *;
      `;
      
      const result = await tempPool.query(updateQuery, [item_name, item_price, id]);
  
      if (result.rowCount === 0) {
        return res.status(404).json({ error: "Food item not found" });
      }
  
      res.json({ message: "Food item updated successfully", item: result.rows[0] });
    } catch (error) {
      console.error("Error updating food item:", error);
      res.status(500).json({ error: "Internal Server Error" });
    }
  });

  module.exports = router;