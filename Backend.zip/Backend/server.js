const express = require("express");
// const { Pool } = require("pg");
const jwt = require("jsonwebtoken");
const app = express();
app.use(express.json());
app.use('/image', express.static('image'));
const multer = require('multer');
const cors = require('cors');
const validator = require('validator');
const nodemailer = require('nodemailer');
// const validateAPIKey = require('./api/apikeyMiddleware');
const https = require('https');
const fs = require('fs');

// Load SSL certificate and key
// const privateKey = fs.readFileSync('/etc/letsencrypt/live/burgerspotcafeteria.com/privkey.pem', 'utf8');
// const certificate = fs.readFileSync('/etc/letsencrypt/live/burgerspotcafeteria.com/fullchain.pem', 'utf8');
const privateKey = fs.readFileSync('./cert/key.pem', 'utf8');
const certificate = fs.readFileSync('./cert/cert.pem', 'utf8');
const credentials = { key: privateKey, cert: certificate };

// Create HTTPS server
const httpsServer = https.createServer(credentials, app);

const userAddonRouter = require("./api/userAddon");
const adminAddonRouter = require("./api/adminAddon");
const deliveryRouter = require("./api/delivery");
// const menuRouter = require("./api/WeeklyMenu");
const serviceRouter = require("./api/playstoreUpdate")
// const setupMeals = require("./api/setupMeals")
// twilio
const loginSystem = require("./api/LoginSystem")

const bodyParser = require("body-parser");
const twilio = require("twilio");
app.use(cors());

const {
  createDatabase,
  getDatabasePool,
  createTable,
  // createSetupMealsTable,
  createImagesTable,
  createFoodItemsTable,
  createAddonTable,
  createDeliveryTable,
  // createMenuTable,
  createDeleteUserTable,
  createUpdatePushTable,
  UpdateRating,
  createAddressTable,
} = require("./db");

const validateAPIKey = require("./api/apikeyMiddleware");

// Routes
app.use("/", userAddonRouter);
app.use("/", adminAddonRouter);
app.use("/",deliveryRouter);
// app.use("/",menuRouter);
app.use("/",serviceRouter);
app.use ("/",loginSystem)
// app.use("/",setupMeals);


// Saved images

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, './image'); 
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname); 
  },
});

const upload = multer({
  storage: multer.memoryStorage(), 
});

// upload image dashboard

app.post("/uploadImage", upload.single('image'), async (req, res) => {
  try {
    const tempPool = getDatabasePool();

    if (!req.file) {
      return res.status(400).json({ status: false, error: "No image file provided" });
    }

    const imageBuffer = req.file.buffer;

    // const imageUrl = `https://burgerspotcafeteria.com:5001/image/${req.file.originalname}`;
    const imageUrl = `http://localhost:5001/image/${req.file.originalname}`;
    try {
      const existingImage = await tempPool.query(
        "SELECT * FROM images WHERE image_url = $1",
        [imageUrl]
      );

      if (existingImage.rows.length > 0) {
        return res.json({ status: false, message: "Image with the same name already exists" });
      }
      const fs = require('fs');
      const imagePath = `./image/${req.file.originalname}`;
      fs.writeFileSync(imagePath, imageBuffer);

      const result = await tempPool.query(
        "INSERT INTO images (image_url) VALUES ($1) RETURNING *",
        [imageUrl]
      );

      const image = result.rows[0];

      res.json({ status: true, message: "Image uploaded successfully", image });
    } catch (error) {
      console.log("Error saving image URL to the database:", error);
      res.status(500).json({ status: false, error: "Internal Server Error" });
    }
  } catch (error) {
    console.log("Error creating pool:", error);
    res.status(500).json({ status: false, error: "Internal Server Error" });
  }
});

// get image dashboard
app.get("/listImages", async (req, res) => {
  try {
    const tempPool = getDatabasePool();

    const getImagesQuery = 'SELECT id, image_url FROM images';

    const result = await tempPool.query(getImagesQuery);
    res.json(result.rows);
  } catch (error) {
    console.error('Error retrieving images:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// image status update dashboard
app.post('/addons/:id', async (req, res) => {
  const addonId = req.params.id;
  const newStatus = req.body.status;
  const tempPool = getDatabasePool();
  try {
    const updateAddonStatusQuery = `
      UPDATE admin_addon
      SET status = $1
      WHERE id = $2
    `;
    await tempPool.query(updateAddonStatusQuery, [newStatus, addonId]);
    res.status(200).json({ message: ' status updated successfully' });
  } catch (error) {
    console.error('Error updating  status:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// delete image dashboard
app.delete("/deleteImage/:id", async (req, res) => {
  try {
    const tempPool = getDatabasePool();
    const { id } = req.params;

    try {
      const result = await tempPool.query("SELECT * FROM images WHERE id = $1", [id]);

      if (result.rows.length === 0) {
        return res.json({ status: false, message: "Image not found" });
      }

      await tempPool.query("DELETE FROM images WHERE id = $1", [id]);

      const fs = require('fs');
      const imagePath = `./image/${result.rows[0].image_url.split('/').pop()}`;
      fs.unlinkSync(imagePath);

      res.json({ status: true, message: "Image deleted successfully" });
    } catch (error) {
      console.error("Error deleting image:", error);
      res.status(500).json({ status: false, error: "Internal Server Error" });
    }
  } catch (error) {
    console.error("Error creating pool:", error);
    res.status(500).json({ status: false, error: "Internal Server Error" });
  }
})




createDatabase().then(() => createTable())
  // .then(() => createSetupMealsTable())
  .then(() => createImagesTable()) 
  .then(() => createFoodItemsTable()) 
  .then(() => createAddonTable()) 
  .then(() => createDeliveryTable()) 
  // .then(() => createMenuTable()) 
  .then(() => createDeleteUserTable()) 
  .then(() => createUpdatePushTable()) 
  .then(() => UpdateRating()) 
  .then(() => createAddressTable()) 
  .then(() => {

    const PORT = process.env.PORT || 9000;

    // app.listen(PORT, () => {
    //   console.log(`Http Server is running on port ${PORT}`);
    // });

// Start HTTPS

    httpsServer.listen(PORT, () => {
      console.log(`Https Server is running on port ${PORT}`);
    });
    
    
  }).catch((error) => console.error("Error initializing:", error));



  // Total 34 api