const express = require('express')
const cors = require('cors');
const https = require('https');
const fs = require('fs');
const bodyParser = require('body-parser');


const app = express();

const PORT = 5001;

app.use(express.json());
app.use(bodyParser.json());
app.use(cors());

const privateKey = fs.readFileSync('./cert/key.pem', 'utf8');
const certificate = fs.readFileSync('./cert/cert.pem', 'utf8');

const credentials = { key: privateKey, cert: certificate };

// Create HTTPS server
const httpsServer = https.createServer(credentials, app);

//  your API key 
const apiKey = '12345';

// Middleware to check API key
const apiKeyMiddleware = (req, res, next) => {
  const providedApiKey = req.headers['x-api-key'];

  if (!providedApiKey || providedApiKey !== apiKey) {
    return res.status(401).json({ error: 'Unauthorized. Invalid API key.' });
  }
  next();
};

// app.use(apiKeyMiddleware);

const { createDatabase, createLabTable, createTODTable, createControlRoomTable} =require('./model/db')

const Router=require('./controller/router')


app.use("/", Router);
createDatabase()
    .then(() => createLabTable())
    .then(() => createTODTable())
    .then(()=>createControlRoomTable())
    .then(() => {
    app.listen(PORT, () => {
     console.log(`Server is running at http://localhost:${PORT}/`);
})
})
