const express = require("express");
const router = express.Router();
const { getDatabasePool } = require("../model/db");

//  Lab

router.post("/lab", async (req, res) => {
  const {
    date,
    hour,
    rw_ph,
    rw_turbidity,
    tw_ph,
    tw_turbidity,
    tw_residual_chlorine,
  } = req.body;

  const tempPool = getDatabasePool();

  try {
    const insertQuery = `
        INSERT INTO lab (date, hour, rw_ph, rw_turbidity, tw_ph, tw_turbidity, tw_residual_chlorine)
        VALUES ($1, $2, $3, $4, $5, $6, $7)
        RETURNING *;
      `;

    const result = await tempPool.query(insertQuery, [
      date,
      hour,
      rw_ph,
      rw_turbidity,
      tw_ph,
      tw_turbidity,
      tw_residual_chlorine,
    ]);

    res.status(201).json({
      message: "Lab data inserted successfully",
      labData: result.rows[0],
    });
  } catch (error) {
    console.error("Error inserting data into lab table:", error);
    res.status(500).json({
      message: "Error inserting data",
      error: error.message,
    });
  } finally {
    await tempPool.end();
  }
});

router.get("/lab", async (req, res) => {
  const tempPool = getDatabasePool();
  try {
    const result = await tempPool.query("SELECT * FROM lab");
    const labData = result.rows;
    res.json({ status: true, labData });
  } catch (error) {
    console.error("Error fetching lab data:", error);
    res.status(500).json({ status: false, message: "Error fetching lab data" });
  } finally {
    await tempPool.end();
  }
});

// TOD
router.post("/tod", async (req, res) => {
  const {
    date,
    hour,
    kwh,
    power_factor,
    max_demand,
    line_voltage_R,
    line_voltage_Y,
    line_voltage_B,
    kvah,
    kvarh,
    Z1,
    Z2,
    Z3,
    transformer_1,
    transformer_2,
  } = req.body;

  const tempPool = getDatabasePool();

  try {
    const insertQuery = `
        INSERT INTO tod (date, hour, kwh, power_factor, max_demand, line_voltage_R, line_voltage_Y, line_voltage_B, kvah, kvarh, Z1, Z2, Z3, transformer_1, transformer_2)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15)
        RETURNING *;
      `;

    const result = await tempPool.query(insertQuery, [
      date,
      hour,
      kwh,
      power_factor,
      max_demand,
      line_voltage_R,
      line_voltage_Y,
      line_voltage_B,
      kvah,
      kvarh,
      Z1,
      Z2,
      Z3,
      transformer_1,
      transformer_2,
    ]);

    res.status(201).json({
      message: "TOD data inserted successfully",
      todData: result.rows[0],
    });
  } catch (error) {
    console.error("Error inserting data into tod table:", error);
    res.status(500).json({
      message: "Error inserting data",
      error: error.message,
    });
  } finally {
    await tempPool.end();
  }
});

// GET API 
router.get('/tod', async (req, res) => {
    const tempPool = getDatabasePool();
  
    try {
      const query = 'SELECT * FROM tod;';
      const result = await tempPool.query(query);
  
      res.status(200).json({
        message: 'TOD data retrieved successfully',
        todData: result.rows
      });
    } catch (error) {
      console.error("Error retrieving data from tod table:", error);
      res.status(500).json({
        message: "Error retrieving data",
        error: error.message
      });
    } finally {
      await tempPool.end();
    }
  });
  

// Controlroom
router.post("/controlroom", async (req, res) => {
  const { date, hour, rw_vol_month, tw_volume_month, backwash_water_used } =
    req.body;

  const tempPool = getDatabasePool();

  try {
    const insertQuery = `
        INSERT INTO controlroom (date, hour, rw_vol_month, tw_volume_month, backwash_water_used)
        VALUES ($1, $2, $3, $4, $5)
        RETURNING *;
      `;

    const result = await tempPool.query(insertQuery, [
      date,
      hour,
      rw_vol_month,
      tw_volume_month,
      backwash_water_used,
    ]);

    res.status(201).json({
      message: "ControlRoom data inserted successfully",
      controlRoomData: result.rows[0],
    });
  } catch (error) {
    console.error("Error inserting data into controlroom table:", error);
    res.status(500).json({
      message: "Error inserting data",
      error: error.message,
    });
  } finally {
    await tempPool.end();
  }
});
// GET API 
router.get('/controlroom', async (req, res) => {
    const tempPool = getDatabasePool();
  
    try {
      const query = 'SELECT * FROM controlroom;';
      const result = await tempPool.query(query);
  
      res.status(200).json({
        message: 'ControlRoom data retrieved successfully',
        controlRoomData: result.rows
      });
    } catch (error) {
      console.error("Error retrieving data from controlroom table:", error);
      res.status(500).json({
        message: "Error retrieving data",
        error: error.message
      });
    } finally {
      await tempPool.end();
    }
  });
  
module.exports = router;
