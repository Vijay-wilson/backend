const { Pool } = require("pg");
const config = require("./config");

const createDatabase = async () => {
    const tempPool = new Pool({
        user: config.database.user,
        host: config.database.host,
        database: "postgres",
        password: config.database.password,
        port: config.database.port,
    });
  try {
    await tempPool.query("CREATE DATABASE amrut");
    console.log("Database created successfully");
  } catch (error) {
    if (error.code === "42P04") {
      console.log("Database already exists");
    } else {
      console.error("Error creating database:", error);
      process.exit(-1);
    }
  } finally {
    await tempPool.end();
  }
}

const getDatabasePool = () => {
  return new Pool({
    user: config.database.user,
    host: config.database.host,
    database: config.database.databaseName,
    password: config.database.password,
    port: config.database.port,
  });
};

const createLabTable = async () => { 
  const tempPool = getDatabasePool();
  const createTableLabQuery = `
      CREATE TABLE IF NOT EXISTS lab (
        id SERIAL PRIMARY KEY,
        date VARCHAR(50),
        hour VARCHAR(50),
        rw_ph FLOAT,
        rw_turbidity FLOAT,
        tw_ph FLOAT,
        tw_turbidity FLOAT,
        tw_residual_chlorine FLOAT
      );
    `;

try {
    await tempPool.query(createTableLabQuery);
    console.log("Users table created successfully");
  } catch (error) {
    console.log("Error creating users table:", error);
    process.exit(-1);
  } finally {
    await tempPool.end();
} 
}

const createTODTable = async () => { 
  const tempPool = getDatabasePool();
  const createTableTODQuery = `
      CREATE TABLE IF NOT EXISTS tod (
            id SERIAL PRIMARY KEY,
            date VARCHAR(50),
            hour VARCHAR(50),
            kwh FLOAT,
            power_factor FLOAT,
            max_demand FLOAT,
            line_voltage_R FLOAT,
            line_voltage_Y FLOAT,
            line_voltage_B FLOAT,
            kvah FLOAT,
            kvarh FLOAT,
            Z1 FLOAT,
            Z2 FLOAT,
            Z3 FLOAT,
            transformer_1 BOOLEAN,
            transformer_2 BOOLEAN
      );
    `;

try {
    await tempPool.query(createTableTODQuery);
    console.log("Users table created successfully");
  } catch (error) {
    console.log("Error creating users table:", error);
    process.exit(-1);
  } finally {
    await tempPool.end();
} 
}


const createControlRoomTable = async () => { 
  const tempPool = getDatabasePool();
  const createTableControlRoomQuery = `
      CREATE TABLE IF NOT EXISTS controlroom (
        id SERIAL PRIMARY KEY,
        date VARCHAR(50),
        hour VARCHAR(50),
        rw_vol_month FLOAT,
        tw_volume_month FLOAT,
        backwash_water_used FLOAT
      );
    `;

try {
    await tempPool.query(createTableControlRoomQuery);
    console.log("Users table created successfully");
  } catch (error) {
    console.log("Error creating users table:", error);
    process.exit(-1);
  } finally {
    await tempPool.end();
} 
}



module.exports = {
  getDatabasePool,
  createDatabase,
  createLabTable,
  createTODTable,
  createControlRoomTable
}