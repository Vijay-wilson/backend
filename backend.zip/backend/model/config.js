
module.exports = {
    database: {
      user: 'postgres',
      host: '34.131.227.161',
      databaseName: 'amrut',
      password: '143143',
      port: 5432, 
    }
  };
  
