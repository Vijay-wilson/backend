

const os = require('os');

function getSystemData() {
    const currentDate = new Date().toISOString();

    const memoryUsage = process.memoryUsage();
    const totalMemory = os.totalmem();
    const freeMemory = os.freemem();
    const cpuLoad = os.loadavg();
    const cpuCores = os.cpus();
    const uptime = os.uptime();
    const networkInterfaces = os.networkInterfaces();
    const hostname = os.hostname();
    const platform = os.platform();
    const architecture = os.arch();
    const cpuUsage = process.cpuUsage();
    const userInfo = os.userInfo();
    const release = os.release();

    const systemInfo = {
        currentDate: currentDate,
        memoryUsage: {
            rss: `${(memoryUsage.rss / 1024 / 1024).toFixed(2)} MB`,
            heapTotal: `${(memoryUsage.heapTotal / 1024 / 1024).toFixed(2)} MB`,
            heapUsed: `${(memoryUsage.heapUsed / 1024 / 1024).toFixed(2)} MB`,
            external: `${(memoryUsage.external / 1024 / 1024).toFixed(2)} MB`,
        },
        totalMemory: `${(totalMemory / 1024 / 1024 / 1024).toFixed(2)} GB`,
        freeMemory: `${(freeMemory / 1024 / 1024 / 1024).toFixed(2)} GB`,
        cpuLoad: cpuLoad.map(load => load.toFixed(2)),
        cpuCores: cpuCores.length,
        cpuDetails: cpuCores.map((cpu, index) => ({
            core: index + 1,
            model: cpu.model,
            speed: `${cpu.speed} MHz`,
            times: cpu.times
        })),
        cpuUsage: {
            user: `${(cpuUsage.user / 1000).toFixed(2)} ms`,
            system: `${(cpuUsage.system / 1000).toFixed(2)} ms`
        },
        uptime: `${Math.floor(uptime / 60 / 60)} hours, ${Math.floor((uptime / 60) % 60)} minutes, ${Math.floor(uptime % 60)} seconds`,
        networkInterfaces: Object.entries(networkInterfaces).reduce((acc, [key, value]) => {
            acc[key] = value.map(iface => ({
                address: iface.address,
                netmask: iface.netmask,
                family: iface.family,
                mac: iface.mac,
                internal: iface.internal
            }));
            return acc;
        }, {}),
        hostname: hostname,
        platform: platform,
        architecture: architecture,
        userInfo: {
            username: userInfo.username,
            homedir: userInfo.homedir,
            shell: userInfo.shell
        },
        release: release
    };

    return systemInfo;
}

module.exports = { getSystemData };
