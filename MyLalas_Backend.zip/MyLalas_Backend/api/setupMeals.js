const express = require("express");
const { getDatabasePool } = require("../db");
const cron = require("node-cron");
const router = express.Router();
const moment = require("moment");

// Cron 1
// Function to decrement noOfDays

const updateSubscriptionStatus = async () => {
  const currentDate = new Date();
  currentDate.setDate(currentDate.getDate() - 1);
  const formattedCurrentDate = `${currentDate.getDate()}/${
    currentDate.getMonth() + 1
  }/${currentDate.getFullYear()}`;

  const tempPool = getDatabasePool();
  console.log(formattedCurrentDate);

  const updateQuery = `
    UPDATE setupmeals
    SET subscription_status = 'End'
    WHERE end_date = $1;
  `;

  try {
    await tempPool.query(updateQuery, [formattedCurrentDate]);
    console.log("Subscription statuses updated successfully");
  } catch (error) {
    console.log("Error updating subscription statuses:", error);
    process.exit(-1);
  } finally {
    await tempPool.end();
  }
};

// cron.schedule('*/10 * * * * *', () => {
//   updateSubscriptionStatus();
// });

// Cron 2
const updateSetupMealsTable = async () => {
  const tempPool = getDatabasePool();

  const updateSetupMealsTableQuery = `
      UPDATE setupmeals
      SET
        breakfast_delivery = FALSE, 
        lunch_delivery = FALSE,
        dinner_delivery = FALSE,
        breakfast_review = FALSE,
        lunch_review = FALSE,
        dinner_review = FALSE;
    `;

  try {
    await tempPool.query(updateSetupMealsTableQuery);
    console.log("Setupmeals table updated successfully");
  } catch (error) {
    console.log("Error updating setupmeals table:", error);
    process.exit(-1);
  } finally {
    await tempPool.end();
  }
};



// Cron 3
const updateSubscriptionPauseStatus = async () => {
  const tempPool = getDatabasePool();

  try {
    // Get the current date in dd/m/yyyy format without leading zero for the month
    const currentDate = new Date();
    const day = currentDate.getDate().toString().padStart(2, '0');
    const month = (currentDate.getMonth() + 1).toString(); 
    const year = currentDate.getFullYear();
    const formattedDate = `${day}/${month}/${year}`;

    const updateQuery = `
      UPDATE setupmeals
      SET subscription_status = 'Active'
      WHERE sub_pause_start_date = $1
    `;

    const result = await tempPool.query(updateQuery, [formattedDate]);
    console.log(`Subscription status updated to Active for ${result.rowCount} records.`);
  } catch (error) {
    console.log("Error updating subscription status:", error);
  } finally {
    await tempPool.end();
  }
};

// // Schedule the decrementSubscriptionDayCount function to run every day at midnight in Kolkata timezone

cron.schedule(
  "0 0 * * *",
  () => {
    updateSubscriptionStatus();
    updateSetupMealsTable();
    updateSubscriptionPauseStatus();
  },
  {
    timezone: "Asia/Kolkata",
  }
);



// Schedule the decrementNoOfDays function to run every 10 seconds for testing

// cron.schedule('*/10 * * * * *', () => {
//   updateSubscriptionPauseStatus();
// });



// create meals Mainapp
router.post("/createSetupMeals", async (req, res) => {
  try {
    const tempPool = getDatabasePool();

    const {
      orderId,
      start_date,
      end_date,
      sub_pause_start_date,
      sub_pause_end_date,
      sub_pause_item_start,
      transactionId,
      currentTime,
      noOfDays,
      totalPricePaid,
      paymentMethod,
      totalPerDayCost,
      tokens,
      subscription_status,
      uid,
      order_status,
      subTotal,
      gst,
      deliveryCharge,
      userdata,
      breakfast_delivery,
      lunch_delivery,
      dinner_delivery,
      breakfast_review,
      lunch_review,
      dinner_review,
      subscription_day_count,
      discount,
      cancel_date,
      multiple_date // New field
    } = req.body;

    try {
      const result = await tempPool.query(
        `
        INSERT INTO setupmeals (
          orderId, subscription_status, uid, subscription_details, order_status, subTotal, gst, deliveryCharge, userdata,
          breakfast_delivery, lunch_delivery, dinner_delivery, breakfast_review, lunch_review, dinner_review, subscription_day_count,
          discount, start_date, end_date, sub_pause_start_date, sub_pause_end_date, sub_pause_item_start, cancel_date, multiple_date
        )
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22, $23, $24)
        ON CONFLICT (orderId) DO UPDATE 
        SET 
          subscription_status = $2, 
          uid = $3, 
          subscription_details = $4, 
          order_status = $5, 
          subTotal = $6, 
          gst = $7, 
          deliveryCharge = $8, 
          userdata = $9,
          breakfast_delivery = $10, 
          lunch_delivery = $11, 
          dinner_delivery = $12, 
          breakfast_review = $13, 
          lunch_review = $14, 
          dinner_review = $15,
          subscription_day_count = $16,
          discount = $17,
          start_date = $18,
          end_date = $19,
          sub_pause_start_date = $20,
          sub_pause_end_date = $21,
          sub_pause_item_start = $22,
          cancel_date = $23,
          multiple_date = $24
        RETURNING *;
        `,
        [
          orderId,
          subscription_status,
          uid,
          {
            startDate: start_date,
            endDate: end_date,
            transactionId,
            currentTime,
            noOfDays,
            totalPricePaid,
            paymentMethod,
            totalPerDayCost,
            tokens,
          },
          order_status,
          subTotal,
          gst,
          deliveryCharge,
          JSON.stringify(userdata),
          breakfast_delivery,
          lunch_delivery,
          dinner_delivery,
          breakfast_review,
          lunch_review,
          dinner_review,
          subscription_day_count,
          discount,
          start_date,
          end_date,
          sub_pause_start_date,
          sub_pause_end_date,
          sub_pause_item_start,
          cancel_date,
          JSON.stringify(multiple_date) // New field value passed
        ]
      );

      const setupMeals = result.rows[0];

      if (setupMeals.subscription_details.noOfDays === 0) {
        res.json({ status: true, message: "Subscription ended", setupMeals });
      } else if (result.rows.length === 0) {
        res
          .status(400)
          .json({ status: false, message: "Order ID already exists" });
      } else {
        res.json({
          status: true,
          message: "Order Successfully Completed",
          setupMeals,
        });
      }
    } catch (error) {
      console.log("Error creating or updating setupmeals:", error);
      res.status(500).json({ status: false, error: "Internal Server Error" });
    }
  } catch (error) {
    console.log("Error creating pool:", error);
    res.status(500).json({ status: false, error: "Internal Server Error" });
  }
});



// Change order startus
router.put("/updateOrderStatus/:orderId", async (req, res) => {
  const orderId = req.params.orderId;
  const { orderStatus } = req.body;

  if (![2, 4, 6].includes(orderStatus)) {
    return res
      .status(400)
      .json({ status: false, message: "Invalid orderStatus value" });
  }

  try {
    const tempPool = getDatabasePool();

    const updateOrderStatusQuery = `
        UPDATE setupmeals 
        SET order_status = $1
        WHERE orderId = $2
        RETURNING *;
      `;

    const result = await tempPool.query(updateOrderStatusQuery, [
      orderStatus,
      orderId,
    ]);

    if (result.rows.length === 0) {
      return res
        .status(404)
        .json({
          status: false,
          message: "No setupmeals found with the provided orderId",
        });
    }

    const updatedSetupMeal = result.rows[0];
    return res.json({
      status: true,
      message: "Order status updated successfully",
      setupMeal: updatedSetupMeal,
    });
  } catch (error) {
    console.log("Error updating order status:", error);
    return res
      .status(500)
      .json({ status: false, error: "Internal Server Error" });
  }
});

// Get meals dashboard
router.get("/createSetupMeals", async (req, res) => {
  const tempPool = getDatabasePool();

  const getSetupMealsQuery = "SELECT * FROM setupmeals";

  try {
    const result = await tempPool.query(getSetupMealsQuery);
    res.json(result.rows);
  } catch (error) {
    console.error("Error retrieving setupmeals data:", error);
    res.status(500).json({ error: "Internal Server Error" });
  } finally {
    await tempPool.end();
  }
});

router.post("/orders", async (req, res) => {
  const tempPool = getDatabasePool();
  const { orderId } = req.body;

  try {
    const query = `
        SELECT * FROM setupmeals
        WHERE orderId = $1
      `;
    const result = await tempPool.query(query, [orderId]);
    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching orders:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/getsetupmeals", async (req, res) => {
  const { uid } = req.body;
  const tempPool = getDatabasePool();
  if (!uid) {
    return res.status(400).json({ error: "UID is required" });
  }

  try {
    const query = {
      text: "SELECT * FROM setupmeals WHERE uid = $1",
      values: [uid],
    };

    const result = await tempPool.query(query);

    // Send the fetched data as response
    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching setupmeals data:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/update-breakfast-delivery", async (req, res) => {
  const { orderId, breakfast_delivery } = req.body;
  const tempPool = getDatabasePool();
  const updateQuery = `
      UPDATE setupmeals
      SET breakfast_delivery = $1
      WHERE orderId = $2
    `;

  try {
    const result = await tempPool.query(updateQuery, [
      breakfast_delivery,
      orderId,
    ]);
    if (result.rowCount === 0) {
      return res.status(404).json({ message: "Order ID not found" });
    }
    res
      .status(200)
      .json({ message: "Breakfast delivery updated successfully" });
  } catch (error) {
    console.error("Error updating breakfast delivery:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

router.post("/update-lunch-delivery", async (req, res) => {
  const { orderId, lunch_delivery } = req.body;
  const tempPool = getDatabasePool();
  const updateQuery = `
      UPDATE setupmeals
      SET lunch_delivery = $1
      WHERE orderId = $2
    `;

  try {
    const result = await tempPool.query(updateQuery, [lunch_delivery, orderId]);
    if (result.rowCount === 0) {
      return res.status(404).json({ message: "Order ID not found" });
    }
    res.status(200).json({ message: "Lunch delivery updated successfully" });
  } catch (error) {
    console.error("Error updating lunch delivery:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

router.post("/update-dinner-delivery", async (req, res) => {
  const { orderId, dinner_delivery } = req.body;
  const tempPool = getDatabasePool();
  const updateQuery = `
      UPDATE setupmeals
      SET dinner_delivery = $1
      WHERE orderId = $2
    `;

  try {
    const result = await tempPool.query(updateQuery, [
      dinner_delivery,
      orderId,
    ]);
    if (result.rowCount === 0) {
      return res.status(404).json({ message: "Order ID not found" });
    }
    res.status(200).json({ message: "Dinner delivery updated successfully" });
  } catch (error) {
    console.error("Error updating dinner delivery:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

// Update breakfast review
router.post("/update-breakfast-review", async (req, res) => {
  const { orderId, breakfast_review } = req.body;
  const tempPool = getDatabasePool();
  const updateQuery = `
    UPDATE setupmeals
    SET breakfast_review = $1
    WHERE orderId = $2
  `;

  try {
    const result = await tempPool.query(updateQuery, [
      breakfast_review,
      orderId,
    ]);
    if (result.rowCount === 0) {
      return res.status(404).json({ message: "Order ID not found" });
    }
    res.status(200).json({ message: "Breakfast review updated successfully" });
  } catch (error) {
    console.error("Error updating breakfast review:", error);
    res.status(500).json({ message: "Internal server error" });
  } finally {
    await tempPool.end();
  }
});

// Update lunch review
router.post("/update-lunch-review", async (req, res) => {
  const { orderId, lunch_review } = req.body;
  const tempPool = getDatabasePool();
  const updateQuery = `
    UPDATE setupmeals
    SET lunch_review = $1
    WHERE orderId = $2
  `;

  try {
    const result = await tempPool.query(updateQuery, [lunch_review, orderId]);
    if (result.rowCount === 0) {
      return res.status(404).json({ message: "Order ID not found" });
    }
    res.status(200).json({ message: "Lunch review updated successfully" });
  } catch (error) {
    console.error("Error updating lunch review:", error);
    res.status(500).json({ message: "Internal server error" });
  } finally {
    await tempPool.end();
  }
});




// Update dinner review
router.post("/update-dinner-review", async (req, res) => {
  const { orderId, dinner_review } = req.body;
  const tempPool = getDatabasePool();
  const updateQuery = `
    UPDATE setupmeals
    SET dinner_review = $1
    WHERE orderId = $2
  `;

  try {
    const result = await tempPool.query(updateQuery, [dinner_review, orderId]);
    if (result.rowCount === 0) {
      return res.status(404).json({ message: "Order ID not found" });
    }
    res.status(200).json({ message: "Dinner review updated successfully" });
  } catch (error) {
    console.error("Error updating dinner review:", error);
    res.status(500).json({ message: "Internal server error" });
  } finally {
    await tempPool.end();
  }
});
// pause api
router.post("/update-pause", async (req, res) => {
  const { orderId, start_date, end_date, sub_pause, subscription_day_count } =
    req.body;
  const tempPool = getDatabasePool();
  if (!orderId) {
    return res.status(400).send("orderId is required");
  }

  const updateQuery = `
    UPDATE setupmeals
    SET 
      start_date = $1,
      end_date = $2,
      sub_pause = $3,
      subscription_day_count = $4
    WHERE orderId = $5
  `;

  const values = [
    start_date,
    end_date,
    sub_pause,
    subscription_day_count,
    orderId,
  ];

  try {
    const result = await tempPool.query(updateQuery, values);

    if (result.rowCount === 0) {
      return res.status(404).send("No record found for the given orderId");
    }

    res.status(200).send("Setupmeal updated successfully");
  } catch (error) {
    console.error("Error updating setupmeal:", error);
    res.status(500).send("Internal Server Error");
  }
});

router.post("/update-sub-pause", async (req, res) => {
  const {
    orderId,
    sub_pause_start_date,
    sub_pause_end_date,
    sub_pause_item_start,
    subscription_status,
    start_date, 
    end_date    
  } = req.body;

  const tempPool = getDatabasePool();

  if (!orderId || sub_pause_start_date === undefined || sub_pause_end_date === undefined || sub_pause_item_start === undefined || subscription_status === undefined || start_date === undefined || end_date === undefined) {
    return res
      .status(400)
      .json({ error: "orderId, sub_pause_start_date, sub_pause_end_date, sub_pause_item_start, subscription_status, start_date, and end_date are required" });
  }

  const updateQuery = `
    UPDATE setupmeals
    SET sub_pause_start_date = $1,
        sub_pause_end_date = $2,
        sub_pause_item_start = $3,
        subscription_status = $4,
        start_date = $5,    
        end_date = $6     
    WHERE orderId = $7;
  `;

  try {
    const result = await tempPool.query(updateQuery, [
      sub_pause_start_date,
      sub_pause_end_date,
      sub_pause_item_start,
      subscription_status,
      start_date,  
      end_date,    
      orderId
    ]);

    if (result.rowCount === 0) {
      return res.status(404).json({ error: "Order not found" });
    }

    res
      .status(200)
      .json({ message: "Subscription pause details updated successfully" });
  } catch (error) {
    console.error("Error updating subscription pause details:", error);
    res.status(500).json({ error: "Internal Server Error" });
  } finally {
    await tempPool.end();
  }
});

router.post('/modify', async (req, res) => {
  const {
    uid,
    order_id,
    start_date,
    end_date,
    pause_date,
    breakfast,
    lunch,
    dinner,
    pause_status,
    pause_reason,
  } = req.body;

  const tempPool = getDatabasePool();
  const insertPauseQuery = `
    INSERT INTO modify (uid, order_id, start_date, end_date, pause_date, breakfast, lunch, dinner, pause_status, pause_reason)
    VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
    RETURNING *;
  `;

  try {
    const result = await tempPool.query(insertPauseQuery, [
      uid,
      order_id,
      start_date,
      end_date,
      pause_date,
      breakfast,
      lunch,
      dinner,
      pause_status,
      pause_reason,
    ]);

    res.status(201).json({
      message: 'Data modify successfully',
      data: result.rows[0],
    });
  } catch (error) {
    console.error('Error inserting data into modify table:', error);
    res.status(500).json({
      message: 'Failed to insert data',
      error: error.message,
    });
  } finally {
    await tempPool.end();
  }
});
router.post('/pause', async (req, res) => {
  const { uid, order_id } = req.body;
  const tempPool = getDatabasePool();
  if (!uid || !order_id) {
    return res.status(400).json({ error: 'Missing uid or order_id' });
  }

  const query = `
    SELECT * FROM modify 
    WHERE uid = $1 AND order_id = $2;
  `;

  try {
    const result = await tempPool.query(query, [uid, order_id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'No data found' });
    }

    res.json(result.rows);
  } catch (error) {
    console.error('Error retrieving data:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.get('/delivery-users', async (req, res) => {
  const tempPool = getDatabasePool();
  try {
    const result = await tempPool.query('SELECT * FROM delivery_user');
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching delivery users:', error);
    res.status(500).json({ error: 'Failed to fetch delivery users' });
  }
});


router.post('/delivery-users', async (req, res) => {
  const { delivery_user, user_status, route_name } = req.body;
  const tempPool = getDatabasePool();
  const addDeliveryUserQuery = `
    INSERT INTO delivery_user (delivery_user, user_status, route_name)
    VALUES ($1, $2, $3)
    RETURNING *;
  `;

  try {
    const result = await tempPool.query(addDeliveryUserQuery, [delivery_user, user_status, route_name]);
    res.status(201).json({
      message: "Delivery user added successfully",
      user: result.rows[0],
    });
  } catch (error) {
    console.error("Error adding delivery user:", error);
    res.status(500).json({
      message: "Error adding delivery user",
      error: error.message,
    });
  }
});

// DELETE API 
router.delete('/delivery-users/:id', async (req, res) => {
  const { id } = req.params;
  const tempPool = getDatabasePool();
  if (!id) {
    return res.status(400).json({ error: 'Missing delivery user id' });
  }

  const deleteQuery = `
    DELETE FROM delivery_user WHERE id = $1 RETURNING *;
  `;

  try {
    const result = await tempPool.query(deleteQuery, [id]);

    if (result.rowCount === 0) {
      return res.status(404).json({ error: 'Delivery user not found' });
    }

    res.status(200).json({ message: 'Delivery user deleted successfully', deletedUser: result.rows[0] });
  } catch (error) {
    console.error('Error deleting delivery user:', error);
    res.status(500).json({ error: 'Failed to delete delivery user' });
  }
});


// Get api
router.get("/pause", async (req, res) => {
  const tempPool = getDatabasePool();
  const getPauseTableDataQuery = `
    SELECT * FROM modify;
  `;

  try {
    const result = await tempPool.query(getPauseTableDataQuery);
    res.status(200).json({
      status: "success",
      data: result.rows,
    });
  } catch (error) {
    console.error("Error retrieving pause table data:", error);
    res.status(500).json({
      status: "error",
      message: "Internal Server Error",
    });
  }
});



module.exports = router;
