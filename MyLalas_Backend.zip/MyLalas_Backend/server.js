const express = require("express");
// const { Pool } = require("pg");
const app = express();
app.use(express.json());
app.use('/image', express.static('image'));
const multer = require('multer');
const cors = require('cors');
const https = require('https');
const fs = require('fs');
const validateAPIKey = require("./api/apikeyMiddleware");

// Load SSL certificate and key
const privateKey = fs.readFileSync('./cert/key.pem', 'utf8');
const certificate = fs.readFileSync('./cert/cert.pem', 'utf8');

const credentials = { key: privateKey, cert: certificate };

// Create HTTPS server
const httpsServer = https.createServer(credentials, app);

const userAddonRouter = require("./api/userAddon");
const adminAddonRouter = require("./api/adminAddon");
const deliveryRouter = require("./api/delivery");
const menuRouter = require("./api/WeeklyMenu");
const serviceRouter = require("./api/playstoreUpdate")
const setupMeals = require("./api/setupMeals")
const main = require("./api/Main")
const twilioRouter = require("./api/twilioRouter");
const { getSystemData } = require("./api/SystemData");
const payment = require("./api/Payment")
app.use(cors());

const {
  createDatabase,
  getDatabasePool,
  createTable,
  createSetupMealsTable,
  createImagesTable,
  createFoodItemsTable,
  createAddonTable,
  createDeliveryTable,
  createDeliverCompleteyTable,
  createMenuTable,
  createDeleteUserTable,
  createUpdatePushTable,
  createRoutesTableAndInsertData,
  createMealPricesTable,
  SubscriptionPauseTable,
  DeliveryUserTable
} = require("./db");



// Routes
app.use("/", userAddonRouter);
app.use("/", adminAddonRouter);
app.use("/",deliveryRouter);
app.use("/",menuRouter);
app.use("/",serviceRouter);
app.use("/",setupMeals);
app.use("/",main);
app.use("/", twilioRouter);
app.use("/",payment);
// System Data Route
app.get("/system-info", (req, res) => {
  const systemData = getSystemData();
  res.json(systemData);
});

// Saved images

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, './image'); 
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname); 
  },
});

const upload = multer({
  storage: multer.memoryStorage(), 
});

// upload image dashboard

app.post("/uploadImage", upload.single('image'), async (req, res) => {
  try {
    const tempPool = getDatabasePool();

    if (!req.file) {
      return res.status(400).json({ status: false, error: "No image file provided" });
    }

    const imageBuffer = req.file.buffer;

    const imageUrl = `https://lalaskitchen.in:3000/image/${req.file.originalname}`;

    try {
      const existingImage = await tempPool.query(
        "SELECT * FROM images WHERE image_url = $1",
        [imageUrl]
      );

      if (existingImage.rows.length > 0) {
        return res.json({ status: false, message: "Image with the same name already exists" });
      }
      const fs = require('fs');
      const imagePath = `./image/${req.file.originalname}`;
      fs.writeFileSync(imagePath, imageBuffer);

      const result = await tempPool.query(
        "INSERT INTO images (image_url) VALUES ($1) RETURNING *",
        [imageUrl]
      );

      const image = result.rows[0];

      res.json({ status: true, message: "Image uploaded successfully", image });
    } catch (error) {
      console.log("Error saving image URL to the database:", error);
      res.status(500).json({ status: false, error: "Internal Server Error" });
    }
  } catch (error) {
    console.log("Error creating pool:", error);
    res.status(500).json({ status: false, error: "Internal Server Error" });
  }
});

// get image dashboard
app.get("/listImages", async (req, res) => {
  try {
    const tempPool = getDatabasePool();

    const getImagesQuery = 'SELECT id, image_url FROM images';

    const result = await tempPool.query(getImagesQuery);
    res.json(result.rows);
  } catch (error) {
    console.error('Error retrieving images:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});



// delete image dashboard
app.delete("/deleteImage/:id", async (req, res) => {
  try {
    const tempPool = getDatabasePool();
    const { id } = req.params;

    try {
      const result = await tempPool.query("SELECT * FROM images WHERE id = $1", [id]);

      if (result.rows.length === 0) {
        return res.json({ status: false, message: "Image not found" });
      }

      await tempPool.query("DELETE FROM images WHERE id = $1", [id]);

      const fs = require('fs');
      const imagePath = `./image/${result.rows[0].image_url.split('/').pop()}`;
      fs.unlinkSync(imagePath);

      res.json({ status: true, message: "Image deleted successfully" });
    } catch (error) {
      console.error("Error deleting image:", error);
      res.status(500).json({ status: false, error: "Internal Server Error" });
    }
  } catch (error) {
    console.error("Error creating pool:", error);
    res.status(500).json({ status: false, error: "Internal Server Error" });
  }
})

// Sub_price
app.get('/sub_prices', (req, res) => {
  const prices = {
      weeklyDiscount: 0.016,
      monthlyDiscount: 0.0133,
      multiComboDiscount: 0.085,
      couponOffers: {
          coupon12: 0.12,
          coupon4: 0.04
      }
  };
  res.json(prices);
});


//Create db 


createDatabase().then(() => createTable())
  .then(() => createSetupMealsTable())
  .then(() => createImagesTable()) 
  .then(() => createFoodItemsTable()) 
  .then(() => createAddonTable()) 
  .then(() => createDeliveryTable()) 
  .then(() => createDeliverCompleteyTable()) 
  .then(() => createMenuTable()) 
  .then(() => createDeleteUserTable()) 
  .then(() => createUpdatePushTable()) 
  .then(() => createRoutesTableAndInsertData()) 
  .then(() => createMealPricesTable()) 
  .then(() => SubscriptionPauseTable()) 
  .then(() => DeliveryUserTable()) 
  .then(() => {

    const PORT = process.env.PORT || 3000;

    // app.listen(PORT, () => {
    //   console.log(`Http Server is running on port ${PORT}`);
    // });

// Start HTTPS

    httpsServer.listen(PORT, () => {
      console.log(`Https Server is running on port ${PORT}`);
    });
    
    
  }).catch((error) => console.error("Error initializing:", error));


// Run api


// const PORT = process.env.PORT || 3000;



// app.listen(PORT, () => {
//   console.log(`Server is running on port ${PORT}`);
// });



    // httpsServer.listen(PORT, () => {
    //   console.log(`Https Server is running on port ${PORT}`);
    // });




  // Total 44 api